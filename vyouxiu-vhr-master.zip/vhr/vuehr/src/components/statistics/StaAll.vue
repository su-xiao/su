<template>
  <div>
    <h1>
      综合信息统计
    </h1>
  </div>
</template>
